<?php   namespace App\Modules\Backend\Requests;

use Illuminate\Foundation\Http\FormRequest;

abstract class Request extends FormRequest{
    //
}