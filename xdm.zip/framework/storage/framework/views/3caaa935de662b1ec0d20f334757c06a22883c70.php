<?php $__env->startSection('title'); ?>
    <?php echo e($page_title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-title">
    <div>
        <h1><i class="fa fa-location-arrow"></i> Define Account</h1>
        <p>Import data of Account</p>
    </div>
</div>

<div class="row">
    <div class="col-md-8">
        <?php echo $__env->make('Backend::account.list-account', ['entries' => $entries, 'qs' => $qs], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

    <div class="col-md-4">
        <?php echo Form::open(['url' => $form_uri . $qs, 'method' => 'post', 'name' => 'accountForm', 'id' => 'accountForm', 'role' => 'form', 'files' => true]); ?>

        <div class="tile">
            <h4 class="tile-title">
                Insert Account
                
            </h4>
            <div class="tile-body">
                

                <div class="form-group row">
                    <div class="col-md-6">
                        <label class="control-label">Account Code <span class="text-danger">*</span></label>
                        <?php echo Form::text('account_code', '', ['id'=>'account_code', 'class' => 'form-control', 'autofocus', 'required']); ?>

                        <?php if($errors->has('account_code')): ?><p class="text-danger"><small><?php echo $errors->first('account_code'); ?></small></p> <?php endif; ?>
                   </div>

                   <div class="col-md-6">
                         <label class="control-label">Account Name <span class="text-danger">*</span></label>
                         <?php echo Form::text('account_name', '', ['id'=>'account_name', 'class' => 'form-control', 'required']); ?>

                         <?php if($errors->has('account_name')): ?><p class="text-danger"><small><?php echo $errors->first('account_name'); ?></small></p> <?php endif; ?>
                   </div>
                </div>

                <div class="animated-checkbox">
                    <label>
                        <?php echo Form::checkbox('show_multiple', '1', false, ['id' => 'chk_show_multiple']); ?><span class="label-text">Insert multiple accounts?</span>
                    </label>
                </div>

                <div id='file_upload' class="col-md-12">
                    <div class="form-group">
                        <label class="control-label">Data File(xls, xlsx, csv)</label>
                        <?php echo Form::file('data_file', ['id'=>'data_file', 'accept'=>'.csv, .xls, .xlsx', 'class' => 'form-control']); ?>

                        <small class="form-text text-muted">The order of colunms: <strong>ACCOUNT-CODE;ACCOUNT-NAME</strong></small>
                        <?php if($errors->has('data_file')): ?><p class="text-danger"><small><?php echo $errors->first('data_file'); ?></small></p> <?php endif; ?>
                    </div>

                    <div class="animated-checkbox">
                        <label>
                            <?php echo Form::checkbox('skip_first_line', '1', false, ['id' => 'chk_skip']); ?><span class="label-text">Skip first line for headers?</span>
                        </label>
                    </div>
                </div>

                
            </div>
            <div class="tile-footer text-right">
                <button class="btn btn-primary" type="submit"><i class="fa fa-save"></i>Save</button>
            </div>
            
        </div>
        <?php echo Form::close(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
    $(function(){
        
        if($('#chk_show_multiple').is(':checked')){
            $('#file_upload').show();
            $('#account_code').attr('disabled', true);
            $('#account_name').attr('disabled', true);
        }
        else{
            $('#account_code').attr('disabled', false);
            $('#account_name').attr('disabled', false);
            $('#file_upload').hide();
        }
        $('#chk_show_multiple').on('click', function(){
            if($(this).is(':checked')){
                $('#account_code').attr('disabled', true);
                $('#account_name').attr('disabled', true);
                $('#file_upload').show(500);
            }
            else{
                $('#account_code').attr('disabled', false);
                $('#account_name').attr('disabled', false);
                $('#file_upload').hide(500);
            }
                
        });
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Backend::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>