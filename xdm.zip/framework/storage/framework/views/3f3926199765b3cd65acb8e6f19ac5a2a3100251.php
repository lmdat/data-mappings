    
    <div class="tile">
        <h4 class="tile-title">
            Item List
            <?php if(session()->has('error-message')): ?>
                <small><label class="badge badge-danger">Oh snap! <?php echo e(session()->get('error-message')); ?></label></small>
            <?php endif; ?>

            <?php if(session()->has('success-message')): ?>
                <small><label class="badge badge-success">Yeah! <?php echo e(session()->get('success-message')); ?></label></small>
            <?php endif; ?>
        </h4>
        <div class="tile-body">
                <table class="table table-hover table-bordered" id="item_table">
                    <thead class="thead-dark">
                        <tr>
                            <th>Code</th>
                            <th>Item Name</th>
                            <th>Type</th>
                            <th>Ledger Key</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr <?php if($item->id == @$curr_id): ?> class='table-primary' <?php endif; ?>>
                            <td><?php echo e($item->id); ?></td>
                            <td><?php echo $item->tmp_name; ?></td>
                            <td><?php echo e($item->mappings_type->type_name); ?></td>
                            <td>
                            <?php
                                //$ledgers = $item->with('ledger_item')->get();
                                $pivot = [];
                                if($item->is_leaf == 1){
                                    $pivot = DB::table('ledger_item')->where('mappings_code', $item->id)
                                        ->where('company_id', session()->get('selected_company'))
                                        ->get();
                                }
                                $n = count($pivot);
                            ?>
                            <?php for($i=0; $i<$n; $i++): ?>
                            <i class="fa fa-check-square-o"></i><small><?php echo e($pivot[$i]->ledger_code); ?></small><?php if($i < $n - 1): ?>&nbsp;<?php endif; ?>
                                <?php if($i % $n == 2): ?> <br/> <?php endif; ?>
                            <?php endfor; ?>
                            
                            </td>
                            <td>
                                <a href="<?php echo e(route('mappings-item-edit', ['id' => $item->id, str_replace('?', '', $qs)])); ?>" class="btn btn-sm btn-warning" role="button"><i class="fa fa-edit"></i>Edit</a>
                            
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="row">
                    <div class="col-md-5">
                        <span>
                            <?php echo e("Displaying {$entries->firstItem()} to {$entries->lastItem()} of {$entries->total()} entries."); ?>

                        </span>
                    </div>

                    <div class="col-md-7">
                        <div class="pull-right">
                            <?php echo $entries->links(); ?>

                        </div>
                        
                        
                        
                        
                    </div>
                </div>
        </div>
        
    </div>
   

    
