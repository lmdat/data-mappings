<?php $__env->startSection('title'); ?>
    <?php echo e($page_title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-title">
    <div>
        <h1><i class="fa fa-location-arrow"></i> Create Ledger Data</h1>
        <p>Import data of Ledger</p>
    </div>
</div>

<div class="row">
   
    <div class="col-md-12">
        <?php echo Form::open(['url' => $form_uri . $qs, 'method' => 'post', 'name' => 'ledgerForm', 'id' => 'ledgerForm', 'role' => 'form', 'files' => false]); ?>

        <div class="tile">
            <h4 class="tile-title">
                Ledger List
                <?php if(session()->has('error-message')): ?>
                    <small><label class="badge badge-danger">Oh snap! <?php echo e(session()->get('error-message')); ?></label></small>
                <?php endif; ?>
    
                <?php if(session()->has('success-message')): ?>
                    <small><label class="badge badge-success">Yeah! <?php echo e(session()->get('success-message')); ?></label></small>
                <?php endif; ?>
            </h4>
            <div class="tile-body">
                <div class="row">
                    <div class="col-md-4">
                        <?php echo Form::select('revision_id', $revisions, $revision_id_selected, ['class' => 'form-control', 'id' => 'revision_id', "multiple"=>false]); ?>

                    </div>
                    
                </div>
                <hr/>
                <table class="table table-hover table-bordered" id="item_table">
                    <thead class="thead-dark">
                        <tr>
                            <th>Ledger Key</th>
                            <th>Base Amount</th>
                            <th>Period</th>
                            
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->ledger_key); ?></td>
                            <td class="text-right"><?php echo e(App\Libs\Utils\Vii::formatCurrency($item->base_amount)); ?></td>
                            <td><?php echo e(substr($item->accounting_period, 0, strlen($item->accounting_period) - 3 )); ?></td>
                            <td>
                            
                            
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            
                <div class="row">
                    <div class="col-md-5">
                        <span>
                            <?php echo e("Displaying {$entries->firstItem()} to {$entries->lastItem()} of {$entries->total()} entries."); ?>

                        </span>
                    </div>
    
                    <div class="col-md-7">
                        <div class="pull-right">
                            <?php echo $entries->links(); ?>

                        </div>
                        
                        
                        
                        
                    </div>
                
                </div>
            </div>
            
        </div>
        <?php echo Form::close(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-link'); ?>
<script src="<?php echo e(asset('vendor/select2/dist/js/select2.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
    $(function(){
        $('#revision_id').select2({
            width: '100%'
        });

        $('#revision_id').on('change', function(e){
            var id = $(this).val();
            window.location.href = "<?php echo e($revision_change_url); ?>" + "&rid=" + id
        });
    })
</script>
<?php $__env->stopSection(); ?>   
    
   

    

<?php echo $__env->make('Backend::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>