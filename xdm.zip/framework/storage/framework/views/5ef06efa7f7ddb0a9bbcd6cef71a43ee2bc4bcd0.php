<?php $__env->startSection('title'); ?>
    <?php echo e($page_title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-title">
    <div>
        <h1><i class="fa fa-location-arrow"></i>Mount Ledger Key to Item</h1>
        <p>Glue Item Code with Ledger Key</p>
    </div>
</div>

<div class="row justify-content-center">
    <div class="col-md-6">
        <?php echo Form::open(['url' => $form_uri . $qs, 'method' => 'post', 'name' => 'itemForm', 'id' => 'itemForm', 'role' => 'form', 'files' => true]); ?>

        <div class="tile">
            <h4 class="tile-title">
                Quick Import
                <?php if(session()->has('error-message')): ?>
                    <small><label class="badge badge-danger">Oh snap! <?php echo e(session()->get('error-message')); ?></label></small>
                <?php endif; ?>

                <?php if(session()->has('success-message')): ?>
                    <small><label class="badge badge-success">Yeah! <?php echo e(session()->get('success-message')); ?></label></small>
                <?php endif; ?>
            </h4>
            <div class="tile-body">
                <div class="form-group">
                    <label class="control-label">Data File(xls, xlsx, csv)</label>
                    <?php echo Form::file('data_file', ['id'=>'data_file', 'accept'=>'.csv, .xls, .xlsx', 'class' => 'form-control']); ?>

                    <small class="form-text text-muted">Order of Column: MAPPING_ITEM_ID | LEDGER_KEY</small>
                    <?php if($errors->has('data_file')): ?><p class="text-danger"><small><?php echo $errors->first('data_file'); ?></small></p> <?php endif; ?> 
                </div>  
                <div class="animated-checkbox">
                    <label>
                        <?php echo Form::checkbox('skip_headers', '1', false, ['id' => 'chk_skip']); ?><span class="label-text">Skip first line for headers?</span>
                    </label>
                </div>   
                
                
                
            </div>
            <div class="tile-footer text-right">
                    <a href="<?php echo e(route('mappings-item', [str_replace('?', '', $qs)])); ?>" class="btn btn-danger" role="button"><i class="fa fa-reply"></i>Back</a>
                <button class="btn btn-primary" type="submit"><i class="fa fa-save"></i>Save</button>
            </div>
            
        </div>
        
        <?php echo Form::close(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css-link'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-link'); ?>
<script src="<?php echo e(asset('vendor/select2/dist/js/select2.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
    $(function(){
        // $('#mounted_account').select2({
        //     width: '100%'
        // });
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Backend::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>