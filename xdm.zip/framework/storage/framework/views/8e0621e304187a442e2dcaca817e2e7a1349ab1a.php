    
    <div class="tile">
        <h4 class="tile-title">
            Account List
            <?php if(session()->has('error-message')): ?>
                <small><label class="badge badge-danger">Oh snap! <?php echo e(session()->get('error-message')); ?></label></small>
            <?php endif; ?>

            <?php if(session()->has('success-message')): ?>
                <small><label class="badge badge-success">Yeah! <?php echo e(session()->get('success-message')); ?></label></small>
            <?php endif; ?>
        </h4>
        <div class="tile-body">
            <table class="table table-hover table-bordered" id="item_table">
                <thead class="thead-dark">
                    <tr>
                        <th>Code</th>
                        <th>Account Name</th>
                        <th>Status</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->account_code); ?></td>
                        <td><?php echo e($item->account_name); ?></td>
                        <td>
                        <?php if($item->status == 1): ?>
                            
                            <a href="#" class="badge badge-info">On</a>
                        <?php else: ?>
                            
                            <a href="#" class="badge badge-secondary">Off</a>
                        <?php endif; ?>
                        </td>
                        <td>
                        <a href="<?php echo e(route('account-edit', ['id' => $item->id, str_replace('?', '', $qs)])); ?>" class="btn btn-sm btn-warning" role="button"><i class="fa fa-edit"></i>Edit</a>
                        
                            
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="row">
                <div class="col-md-5">
                    <span>
                        <?php echo e("Displaying {$entries->firstItem()} to {$entries->lastItem()} of {$entries->total()} entries."); ?>

                    </span>
                </div>

                <div class="col-md-7">
                    <div class="pull-right">
                        <?php echo $entries->links(); ?>

                    </div>
                    
                    
                    
                    
                </div>
            </div>
        </div>
        
    </div>
   

    
