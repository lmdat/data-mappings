<?php $__env->startSection('title'); ?>
    <?php echo e($page_title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-title">
    <div>
        <h1><i class="fa fa-location-arrow"></i> Define Mappings Item</h1>
        <p>Create mappings items from list</p>
    </div>
</div>

<div class="row">
    <div class="col-md-7">
        <?php echo $__env->make('Backend::mappings-item.list-define-item', ['entries' => $entries, 'qs' => $qs], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

    <div class="col-md-5">
        <?php echo Form::open(['url' => $form_uri . $qs, 'method' => 'post', 'name' => 'itemForm', 'id' => 'itemForm', 'role' => 'form', 'files' => false]); ?>

        <div class="tile">
            <h4 class="tile-title">
                Insert Item
                
            </h4>
            <div class="tile-body">
                <div class="form-group">
                    <label class="control-label">Mappings Type</label>
                    <?php echo Form::select('type_id', $type_list, '', ['class' => 'form-control', 'id' => 'type_id']); ?>

                    
                </div>

                <div class="form-group">
                    <label class="control-label">Parent Id</label>
                    <?php echo Form::select('parent_id', $tree_data, '', ['class' => 'form-control', 'id' => 'parent_id']); ?>

                    
                </div>

                <div class="form-group row">
                    <div class="col-md-6">
                        <label class="control-label">Item Name</label>
                        <?php echo Form::text('item_name', '', ['id'=>'item_name', 'class' => 'form-control']); ?>

                   </div>

                   <div class="col-md-6">
                         <label class="control-label">Short Name</label>
                         <?php echo Form::text('short_name', '', ['id'=>'short_name', 'class' => 'form-control']); ?>

                   </div>
                </div>

                <div class="animated-checkbox">
                    <label>
                        <?php echo Form::checkbox('show_multiple', '1', false, ['id' => 'chk_show_multiple']); ?><span class="label-text">Insert multiple items?</span>
                    </label>
                </div>

                <div class="container" id="multiple_item_container">
                    <div class="form-group">
                        <small class="form-text text-muted">Use the fotmat: ITEM_NAME|SHORT_NAME or just ITEM_NAME</small>
                        <?php echo Form::textarea('multiple_item', '', ['id'=>'multiple_item', 'class' => 'form-control', 'placeholder' => 'ITEM_NAME|SHORT_NAME or just ITEM_NAME']); ?>

                    </div>
                </div>
            </div>
            <div class="tile-footer text-right">
                <button class="btn btn-primary" type="submit"><i class="fa fa-save"></i>Save</button>
            </div>
            
        </div>
        <?php echo Form::close(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
    $(function(){
        $('#multiple_item_container').hide()
        $('#chk_show_multiple').on('click', function(){
            if($(this).is(':checked')){
                $('#item_name').attr('disabled', true);
                $('#short_name').attr('disabled', true);
                $('#multiple_item_container').show(500);
            }
            else{
                $('#item_name').attr('disabled', false);
                $('#short_name').attr('disabled', false);
                $('#multiple_item_container').hide(500);
            }
                
        });
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Backend::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>