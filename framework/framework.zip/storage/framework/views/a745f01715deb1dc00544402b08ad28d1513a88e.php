<?php $__env->startSection('title'); ?>
    <?php echo e($page_title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-title">
    <div>
        <h1><i class="fa fa-location-arrow"></i> Settings</h1>
        <p>Truncate data table</p>
    </div>
</div>

<div class="row justify-content-center">
   
    <div class="col-md-6">
        <?php echo Form::open(['url' => $form_uri . $qs, 'method' => 'post', 'name' => 'settingForm', 'id' => 'settingForm', 'role' => 'form', 'files' => false]); ?>

        <div class="tile">
            <h4 class="tile-title">
                Truncate
                <?php if(session()->has('error-message')): ?>
                    <small><label class="badge badge-danger">Oh snap! <?php echo e(session()->get('error-message')); ?></label></small>
                <?php endif; ?>

                <?php if(session()->has('success-message')): ?>
                    <small><label class="badge badge-success">Well done! <?php echo e(session()->get('success-message')); ?></label></small>
                <?php endif; ?>

                <?php if(session()->has('warning-message')): ?>
                    <small><label class="badge badge-warning">Warning! <?php echo e(session()->get('warning-message')); ?></label></small>
                <?php endif; ?>
            </h4>
            <div class="tile-body">
                <?php $__currentLoopData = $table_names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="animated-checkbox">
                    <label>
                    <?php echo Form::checkbox('table[]', $table, false, ['id' => 'chk_table' . $loop->iteration]); ?><span class="label-text">Table <?php echo e($table); ?></span>
                    </label>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="tile-footer text-right">
                <button class="btn btn-primary" type="submit"><i class="fa fa-times"></i>Truncate</button>
            </div>
            
        </div>
        <?php echo Form::close(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Backend::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>