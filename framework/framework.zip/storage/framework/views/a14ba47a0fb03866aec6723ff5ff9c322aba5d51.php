<?php $__env->startSection('title'); ?>
    <?php echo e($page_title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-title">
    <div>
        <h1><i class="fa fa-location-arrow"></i> Define Mappings Item</h1>
        <p>Import data of item from excel or csv file</p>
    </div>
</div>

<div class="row">
    <div class="col-md-7">
        <?php echo $__env->make('Backend::account.list-account', ['entries' => $entries, 'qs' => $qs], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

    <div class="col-md-5">
        <?php echo Form::open(['url' => $form_uri . $qs, 'method' => 'put', 'name' => 'accountForm', 'id' => 'accountForm', 'role' => 'form', 'files' => false]); ?>

        <div class="tile">
            <h4 class="tile-title">
                Edit Account
                
            </h4>
            <div class="tile-body">
                <div class="form-group">
                    <label class="control-label">Company</label>
                    <?php echo Form::select('company_id', $companies, $account->company_id, ['class' => 'form-control', 'id' => 'company_id']); ?>

                    
                </div>

                <div class="form-group row">
                    <div class="col-md-6">
                        <label class="control-label">Account Code</label>
                        <?php echo Form::text('account_code', $account->account_code, ['id'=>'account_code', 'class' => 'form-control', 'readonly']); ?>

                    </div>

                    <div class="col-md-6">
                            <label class="control-label">Account Name</label>
                            <?php echo Form::text('account_name', $account->account_name, ['id'=>'account_name', 'class' => 'form-control']); ?>

                    </div>
                </div>

                
            </div>
            <div class="tile-footer text-right">
                <a href="<?php echo e(route('account', [str_replace('?', '', $qs)])); ?>" class="btn btn-danger" role="button"><i class="fa fa-reply"></i>Back</a>
                <button class="btn btn-primary" type="submit"><i class="fa fa-save"></i>Save</button>
            </div>
            
        </div>
            <?php echo Form::hidden('id', $account->id); ?>    
        <?php echo Form::close(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Backend::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>