<?php $__env->startSection('title'); ?>
    <?php echo e($page_title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-title">
    <div>
        <h1><i class="fa fa-location-arrow"></i> Revision</h1>
        <p>Manage revision of Ledger</p>
    </div>
</div>

<div class="row">
   
    <div class="col-md-12">
        <?php echo Form::open(['url' => $form_uri . $qs, 'method' => 'post', 'name' => 'ledgerForm', 'id' => 'ledgerForm', 'role' => 'form', 'files' => false]); ?>

        <div class="tile">
            <h4 class="tile-title">
                Ledger Revision List
                <?php if(session()->has('error-message')): ?>
                    <small><label class="badge badge-danger">Oh snap! <?php echo e(session()->get('error-message')); ?></label></small>
                <?php endif; ?>
    
                <?php if(session()->has('success-message')): ?>
                    <small><label class="badge badge-success">Yeah! <?php echo e(session()->get('success-message')); ?></label></small>
                <?php endif; ?>
            </h4>
            <div class="tile-body">
                <div class="row">
                    <div class="col-md-4">
                        <?php echo Form::select('upload_id', $upload_entries, $upload_id_selected, ['class' => 'form-control', 'id' => 'upload_id', "multiple"=>false]); ?>

                    </div>
                    
                </div>
                <hr/>
                <table class="table table-hover table-bordered" id="item_table">
                    <thead class="thead-dark">
                        <tr>
                            <th>Id</th>
                            <th>Upload Title</th>
                            <th>Revision Number</th>
                            <th>File name</th>
                            <th>Created at</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $revisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->id); ?></td>
                            <td><?php echo e($item->upload->upload_title); ?></td>
                            <td class="text-right">Revision <?php echo e($item->revision_number); ?></td>
                            <td><a href="<?php echo e(route('revision-download', ['id' => $item->id])); ?>"><?php echo e(basename($item->file_path)); ?></a></td>
                            <td><?php echo e(App\Libs\Utils\Vii::formatDateTime($item->created_at)); ?></td>
                            <td>
                            <a id="delete_revision" href="<?php echo e(route('revision-delete', ['id' => $item->id, str_replace('?', '', $qs)])); ?>" class="btn btn-sm btn-danger" role="button"><i class="fa fa-trash"></i>Delete</a>
                            
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            
                <div class="row">
                    <div class="col-md-5">
                        <span>
                            <?php echo e("Displaying {$entries->firstItem()} to {$entries->lastItem()} of {$entries->total()} entries."); ?>

                        </span>
                    </div>
    
                    <div class="col-md-7">
                        <div class="pull-right">
                            <?php echo $entries->links(); ?>

                        </div>
                        
                        
                        
                        
                    </div>
                
                </div>
            </div>
            
        </div>
        <?php echo Form::close(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-link'); ?>
<script src="<?php echo e(asset('vendor/select2/dist/js/select2.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
    $(function(){
        $('#upload_id').select2({
            width: '100%'
        });

        $('#upload_id').on('change', function(e){
            var id = $(this).val();
            window.location.href = "<?php echo e($upload_change_url); ?>" + "&upid=" + id
        });

        $('#delete_revision').on('click', function(e){
            e.preventDefault();
            // alert($(this).attr('href'));
            if(confirm('Are you sure want to delete this revision?')){
                window.location.href = $(this).attr('href');
            }
        });
    })
</script>
<?php $__env->stopSection(); ?>   
    
   

    

<?php echo $__env->make('Backend::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>