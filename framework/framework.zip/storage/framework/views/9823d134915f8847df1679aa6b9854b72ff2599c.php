<?php $__env->startSection('title'); ?>
    <?php echo e($page_title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-title">
    <div>
        <h1><i class="fa fa-location-arrow"></i> Import Ledger Data</h1>
        <p>Import</p>
    </div>
</div>

<div class="row justify-content-center">
    <div class="col-md-8">
        <?php echo Form::open(['url' => $form_uri . $qs, 'method' => 'post', 'name' => 'importForm', 'id' => 'importForm', 'role' => 'form', 'files' => true]); ?>

        <div class="tile">
            <h4 class="tile-title">
                Step 3/3 <small class="text-muted">Finish</small>

                <?php if(session()->has('error-message')): ?>
                    <label class="badge badge-danger">Oh snap! <?php echo e(session()->get('error-message')); ?></label>
                <?php endif; ?>

                <?php if(session()->has('success-message')): ?>
                    <label class="badge badge-success">Yeah! <?php echo e(session()->get('success-message')); ?></label>
                <?php endif; ?> 
            </h4>    
            <div class="tile-body">
                <?php if($result != null): ?>
               
                <p class="h5"><span class="text-primary"><?php echo e($result['ledger']); ?></span> ledger keys are inserted.</p>
                <p class="h5"><span class="text-primary"><?php echo e($result['account']); ?></span> new accounts are detected and inserted.</p>
                <p class="h5"><span class="text-primary"><?php echo e($result['dim']); ?></span> new dimensions are detected and inserted.</p>
                <?php endif; ?>
            </div>
            <div class="tile-footer text-center">
                <?php if($result != null): ?>
                    <a href="<?php echo e(route('ledger', [str_replace('?', '', $qs)])); ?>" class="btn btn-primary" role="button">Go back Ledger List</a>
                    <a href="<?php echo e(route('import-ledger', ['step' => 1, str_replace('?', '', $qs)])); ?>" class="btn btn-info" role="button">Continue Import</a>
                <?php else: ?>
                    <a href="<?php echo e(route('import-ledger', ['step' => 1, str_replace('?', '', $qs)])); ?>" class="btn btn-warning" role="button">Try Again!</a>
                <?php endif; ?>

                   
                
            </div>
        </div>
            <?php echo Form::hidden('step', $step); ?> 
        <?php echo Form::close(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Backend::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>