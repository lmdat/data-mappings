<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
<aside class="app-sidebar">
    <div class="app-sidebar__user"><img class="app-sidebar__user-avatar" src="https://s3.amazonaws.com/uifaces/faces/twitter/jsa/48.jpg" alt="User Image">
        <div>
            <p class="app-sidebar__user-name"><?php echo e($full_name); ?></p>
            <p class="app-sidebar__user-designation"><small><?php echo e($user_role); ?></small></p>
        </div>
    </div>
    <ul class="app-menu">
        <?php echo @$sidebar_menu; ?>

        
    </ul>
</aside>
