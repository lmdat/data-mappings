<?php $__env->startSection('title'); ?>
    <?php echo e($page_title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="app-title">
    <div>
      <h1><i class="fa fa-location-arrow"></i> Dashboard</h1>
      <p>General Infomartion</p>
    </div>
    
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="tile">
        Welcome <?php echo e($user); ?>

        
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Backend::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>