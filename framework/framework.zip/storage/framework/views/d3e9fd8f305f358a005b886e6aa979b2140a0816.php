<?php $__env->startSection('title'); ?>
    <?php echo e($page_title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-title">
    <div>
        <h1><i class="fa fa-location-arrow"></i> Define Mappings Item</h1>
        <p>Import data of item from excel or csv file</p>
    </div>
</div>

<div class="row">
    <div class="col-md-7">
        <?php echo $__env->make('Backend::mappings-item.list-define-item', ['entries' => $entries, 'qs' => $qs, 'curr_id' => $item->id], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

    <div class="col-md-5">
        <?php echo Form::open(['url' => $form_uri . $qs, 'method' => 'put', 'name' => 'itemForm', 'id' => 'itemForm', 'role' => 'form', 'files' => false]); ?>

        <div class="tile">
            <h4 class="tile-title">
                Edit Item
                
            </h4>
            <div class="tile-body">
                <div class="form-group">
                    <label class="control-label">Mappings Type</label>
                    <?php echo Form::select('type_id', $type_list, $item->type_id, ['class' => 'form-control', 'id' => 'type_id']); ?>

                    
                </div>

                <div class="form-group">
                    <label class="control-label">Parent Id</label>
                    <?php echo Form::select('parent_id', $tree_data, $item->parent_id, ['class' => 'form-control', 'id' => 'parent_id']); ?>

                    
                </div>

                <div class="form-group row">
                    <div class="col-md-6">
                        <label class="control-label">Item Name</label>
                        <?php echo Form::text('item_name', $item->item_name, ['id'=>'item_name', 'class' => 'form-control']); ?>

                   </div>

                   <div class="col-md-6">
                         <label class="control-label">Short Name</label>
                         <?php echo Form::text('short_name', $item->short_name, ['id'=>'short_name', 'class' => 'form-control']); ?>

                   </div>
                </div>

                
            </div>
            <div class="tile-footer text-right">
                <a href="<?php echo e(route('mappings-item', [str_replace('?', '', $qs)])); ?>" class="btn btn-danger" role="button"><i class="fa fa-reply"></i>Back</a>
                <button class="btn btn-primary" type="submit"><i class="fa fa-save"></i>Save</button>
            </div>
            
        </div>
            <?php echo Form::hidden('id', $item->id); ?>    
        <?php echo Form::close(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
    $(function(){
        $('#multiple_item_container').hide()
        $('#chk_show_multiple').on('click', function(){
            if($(this).is(':checked')){
                $('#item_name').attr('disabled', true);
                $('#short_name').attr('disabled', true);
                $('#multiple_item_container').show(500);
            }
            else{
                $('#item_name').attr('disabled', false);
                $('#short_name').attr('disabled', false);
                $('#multiple_item_container').hide(500);
            }
                
        });
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Backend::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>