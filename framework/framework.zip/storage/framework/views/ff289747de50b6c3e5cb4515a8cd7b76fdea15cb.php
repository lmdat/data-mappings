<?php $__env->startSection('title'); ?>
    <?php echo e($page_title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-title">
    <div>
        <h1><i class="fa fa-location-arrow"></i> Create/Edit <?php echo e($typical_name); ?> Dimension</h1>
        <p>Edit <?php echo e($typical_name); ?> Dimension</p>
    </div>
</div>

<div class="row">
    <div class="col-md-8">
        <?php echo $__env->make('Backend::dimension.list-dimension', ['entries' => $entries, 'qs' => $qs, 'curr_id' => $dim->id, 'typical_name' => $typical_name], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

    <div class="col-md-4">
        <?php echo Form::open(['url' => $form_uri . $qs, 'method' => 'put', 'name' => 'dimForm', 'id' => 'dimForm', 'role' => 'form', 'files' => false]); ?>

        <div class="tile">
            <h4 class="tile-title">
                Edit <?php echo e($typical_name); ?> Dimension
                
            </h4>
            <div class="tile-body">
                

                <div class="form-group">
                    <label class="control-label">Dimension Type <span class="text-danger">*</span></label>
                    <?php echo Form::select('dim_type', $type_list, old('dim_type', $dim->dim_type), ['class' => 'form-control', 'id' => 'dim_type']); ?>

                    <?php if($errors->has('dim_type')): ?><p class="text-danger"><small><?php echo $errors->first('dim_type'); ?></small></p> <?php endif; ?> 
                </div>

                <div class="form-group row">
                    <div class="col-md-6">
                        <label class="control-label">Dimension Code</label>
                        <?php echo Form::text('dim_code', $dim->dim_code, ['id'=>'dim_code', 'class' => 'form-control', 'readonly' => true]); ?>

                   </div>

                   <div class="col-md-6">
                         <label class="control-label">Dimension Name <span class="text-danger">*</span></label>
                         <?php echo Form::text('dim_name', old('dim_name', $dim->dim_name), ['id'=>'dim_name', 'class' => 'form-control']); ?>

                         <?php if($errors->has('dim_name')): ?><p class="text-danger"><small><?php echo $errors->first('dim_name'); ?></small></p> <?php endif; ?> 
                   </div>
                </div>

                
            </div>
            <div class="tile-footer text-right">
                <a href="<?php echo e(route('topic-dimension', [str_replace('?', '', $qs)])); ?>" class="btn btn-danger" role="button"><i class="fa fa-reply"></i>Back</a>
                <button class="btn btn-primary" type="submit"><i class="fa fa-save"></i>Save</button>
            </div>
            
        </div>
            <?php echo Form::hidden('id', $dim->id); ?>    
        <?php echo Form::close(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Backend::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>