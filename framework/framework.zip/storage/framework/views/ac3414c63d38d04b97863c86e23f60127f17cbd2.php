<?php $__env->startSection('title'); ?>
    <?php echo e($page_title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-title">
    <div>
        <h1><i class="fa fa-location-arrow"></i> Define Dimension</h1>
        <p>Import data of dimension from excel or csv file</p>
    </div>
</div>

<div class="row">
    <div class="col-md-6">
        <div class="tile">
            <h4 class="tile-title">Dimension List</h4>
            <div class="tile-body">
                    <table class="table table-hover table-bordered" id="dimension_table">
                        <thead>
                            <tr>
                                <th>Code</th>
                                <th>Dimension Name</th>
                                <th>Type</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($k); ?></td>
                                <td><?php echo e($item); ?></td>
                                <td>Department</td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
            </div>
            
        </div>
    </div>

    <div class="col-md-6">
        <?php echo Form::open(['url' => Request::url() . $qs, 'name' => 'dimForm', 'id' => 'dimForm', 'role' => 'form', 'files' => true]); ?>

        <div class="tile">
            <h4 class="tile-title">Insert Dimension</h4>
            <div class="tile-body">
                <div class="form-group">
                    <label class="control-label">Dimension Type</label>
                    <?php echo Form::select('type_id', $type_list, '', ['class' => 'form-control', 'id' => 'type_id']); ?>

                    
                </div>

                <div class="form-group">
                        <label class="control-label">Data File(xls, xlsx, csv)</label>
                    <?php echo Form::file('data_input', ['id'=>'data_input', 'class' => 'form-control']); ?>

                </div>

                <div class="form-group">
                    <div class="form-check">
                        <label class="form-check-label">
                        <input class="form-check-input" type="checkbox">Skip first line for headers?
                        </label>
                    </div>
                </div>
            </div>
            <div class="tile-footer text-right">
                <button class="btn btn-primary" type="button"><i class="fa fa-upload"></i>Upload</button>
            </div>
            
        </div>
        <?php echo Form::close(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Backend::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>