<?php $__env->startSection('title'); ?>
    <?php echo e($page_title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-title">
    <div>
        <h1><i class="fa fa-location-arrow"></i> Manage User</h1>
        <p>Create/Edit User</p>
    </div>
</div>

<div class="row">
    <div class="col-md-8">
        <?php echo $__env->make('Backend::user.list-user', ['entries' => $entries, 'qs' => $qs], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

    <div class="col-md-4">
        <?php echo Form::open(['url' => $form_uri . $qs, 'method' => 'post', 'name' => 'userForm', 'id' => 'userForm', 'role' => 'form', 'files' => false]); ?>

        <div class="tile">
            <h4 class="tile-title">
                Create User
                
            </h4>
            <div class="tile-body">
               
                <div class="form-group row">
                    <div class="col-md-6">
                        <label class="control-label">First Name <span class="text-danger">*</span></label>
                        <?php echo Form::text('first_name', '', ['id'=>'first_name', 'class' => 'form-control', 'autofocus']); ?>

                        <?php if($errors->has('first_name')): ?><p class="text-danger"><small><?php echo $errors->first('first_name'); ?></small></p> <?php endif; ?>
                   </div>

                   <div class="col-md-6">
                         <label class="control-label">Last Name <span class="text-danger">*</span></label>
                         <?php echo Form::text('last_name', '', ['id'=>'last_name', 'class' => 'form-control']); ?>

                         <?php if($errors->has('last_name')): ?><p  class="text-danger"><small><?php echo $errors->first('last_name'); ?></small></p> <?php endif; ?>
                   </div>
                </div>

                <div class="form-group row">
                    <div class="col-md-6">
                        <label class="control-label">Email <span class="text-danger">*</span></label>
                        <?php echo Form::email('email', '', ['id'=>'email', 'class' => 'form-control']); ?>

                        <?php if($errors->has('email')): ?><p  class="text-danger"><small><?php echo $errors->first('email'); ?></small></p> <?php endif; ?>
                    </div>

                    <div class="col-md-6">
                        <label class="control-label">Password <span class="text-danger">*</span></label>
                        <?php echo Form::password('password', ['id'=>'password', 'class' => 'form-control']); ?>

                        <?php if($errors->has('password')): ?><p  class="text-danger"><small><?php echo $errors->first('password'); ?></small></p> <?php endif; ?>
                    </div>
                </div>

                <div class="form-group">
                    <label class="control-label">Role <span class="text-danger">*</span></label>
                    <select id="role_id" name="role_id" class="form-control">
                        <option value="" selected>---</option>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($role->id); ?>" <?php if(in_array($role->power, $disabled_roles)): ?> disabled <?php endif; ?>><?php echo e($role->role_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('role_id')): ?><p class="text-danger"><small><?php echo $errors->first('role_id'); ?></small></p> <?php endif; ?>                    
                    
                    
                </div>

                

                
            </div>
            <div class="tile-footer text-right">
                <button class="btn btn-primary" type="submit"><i class="fa fa-save"></i>Save</button>
            </div>
            
        </div>
        <?php echo Form::close(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Backend::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>