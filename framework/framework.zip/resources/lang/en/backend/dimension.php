<?php
return [
    'define_dimension' => 'Define Dimension',
];