<?php
return [
    'define_mappings_item' => 'Define Mappings Item',
];