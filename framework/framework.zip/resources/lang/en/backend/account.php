<?php
return [
    'define_account' => 'Define Account'
];