<?php
namespace App\Modules\Api\Controllers;

use Illuminate\Routing\Controller as BaseController;
// use Illuminate\Foundation\Validation\ValidatesRequests;
// use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
// use Illuminate\Support\Facades\Auth;

class Controller extends BaseController{
 
    public function __construct(){
        // $this->middleware('ajax_request');
    }
}