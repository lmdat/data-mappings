<?php
return [

    'backend' => [
        'folder_name' => 'Backend',
        'slug_name' => 'cpanel'
    ],

    'frontend' => [
        'folder_name' => 'Frontend',
        'slug_name' => ''
    ],

    'api' => [

        'folder_name' => 'Api',
        'slug_name' => 'api'

    ]
];